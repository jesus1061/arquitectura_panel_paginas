<?php
class Conexion{


	public function obtener_conexion(){
		$dsn = 'mysql:dbname=famevzo1_famevida;charset=utf8;host=127.0.0.1;';
		$usuario = 'famevzo1_admin';
		$contrasena = 'famevidaadmin2022';

		try {
			$gbd = new PDO($dsn, $usuario, $contrasena);
			return $gbd;

		} catch (PDOException $e) {
			echo 'Fallo la conexi��n: ' . $e->getMessage();
		}
	}
	
}
?>