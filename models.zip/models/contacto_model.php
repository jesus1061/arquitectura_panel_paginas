<?php
include_once "conexion.php";
class Contacto_model{

	

	public function ver_contactos(){
		$instancia_conexion = new Conexion();
		$pdo = $instancia_conexion -> obtener_conexion();
		$sql = $pdo->prepare('SELECT * FROM contactos ORDER BY contacto_id DESC');
		$sql->execute();
		$resultado = $sql->fetchAll();

		return $resultado;	
	}
	
	public function crear_contacto($usuario_contacto_nombre, $telefono , $usuario_contacto_correo , $usuario_contacto_mensaje){
	    	$instancia_conexion = new Conexion();
		$pdo = $instancia_conexion -> obtener_conexion();
	    
	    $sql = $pdo->prepare('INSERT INTO contactos (nombre_completo, correo ,mensaje ,telefono ) VALUES 

			(:usuario_contacto_nombre , :usuario_contacto_correo ,  :usuario_contacto_mensaje, :telefono)');

		$sql->bindParam(':usuario_contacto_nombre', $usuario_contacto_nombre);
		$sql->bindParam(':usuario_contacto_correo', $usuario_contacto_correo);
		$sql->bindParam(':usuario_contacto_mensaje', $usuario_contacto_mensaje);
		
		$sql->bindParam(':telefono', $telefono);
		
		$sql->execute();
	}


	


	


}
?>