<?php
include_once "application/controllers/select_controller.php";
//print_r($_GET);
extract($_GET);
$instancia = new Select_controller();
$peticion_blog = $instancia -> listar_publicacion_unica($blog);
foreach($peticion_blog as $blog){

}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<link rel="shortcut icon"  href="../plantilla_front/img/pestana.ico"/>
	<title>Famevida - Programa</title>
	<meta name="viewport" content="width=device-width, user-scalable=no">
	<link rel="stylesheet" href="../plantilla_front/css/new.css">
	<link rel="stylesheet" href="../plantilla_front/css/slider_new.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="../plantilla_front/js/custom.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;700&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css2?family=Merriweather&display=swap" rel="stylesheet"> 
	<style>

		@media only screen and (max-width: 600px) {	body{background-image: url("../plantilla_front/img/banner4.jpg"); background-size: cover;}
		.container-programa{width: 100%;  margin: auto;background-color: white; padding-top: 20px; padding-bottom: 20px; }
		.contenedor-programa{width: 90%; margin: auto; display: table;}
		.portada{width: 95%; -webkit-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			-moz-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75); margin: auto; padding: 10px;}
			.contenido-programa{width: 100%; text-align: justify;}
			.portada .img-archivo{width: 100%; height: 300px;}
			.contenedor-volver{width: 100%;  text-align: center; display: table; padding-top: 5px; padding-bottom: 5px;}
			.contenedor-volver button{padding-top: 8px; padding-bottom: 8px; font-size: 15px; border: none;}
		}

		@media only screen and (min-width: 600px) {	body{background-image: url("../plantilla_front/img/banner4.jpg"); background-size: cover;}
		.container-programa{width: 87.5%;  margin: auto;background-color: white; padding-top: 20px; padding-bottom: 20px; }
		.contenedor-programa{width: 80%; margin: auto; display: table;}
		.portada{width: 95%; -webkit-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			-moz-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75); margin: auto; padding: 10px;}
			.contenido-programa{width: 100%; text-align: justify;}
			.portada .img-archivo{width: 100%; height: 400px;}
			.contenedor-volver{width: 100%;  text-align: center; display: table; padding-top: 5px; padding-bottom: 5px;}
			.contenedor-volver button{padding-top: 8px; padding-bottom: 8px; font-size: 15px; border: none;}
		}

		@media only screen and (min-width: 768px) {	body{background-image: url("../plantilla_front/img/banner4.jpg"); background-size: cover;}
		.container-programa{width: 87.5%;  margin: auto;background-color: white; padding-top: 20px; padding-bottom: 20px; }
		.contenedor-programa{width: 70%; margin: auto; display: table;}
		.portada{width: 95%; -webkit-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			-moz-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75); margin: auto; padding: 10px;}
			.contenido-programa{width: 100%; text-align: justify;}
			.portada .img-archivo{width: 100%; height: 400px;}
			.contenedor-volver{width: 100%;  text-align: center; display: table; padding-top: 5px; padding-bottom: 5px;}
			.contenedor-volver button{padding-top: 8px; padding-bottom: 8px; font-size: 15px; border: none;}
		}

		@media only screen and (min-width: 992px) {	body{background-image: url("../plantilla_front/img/banner4.jpg"); background-size: cover;}
		.container-programa{width: 87.5%;  margin: auto;background-color: white; padding-top: 20px; padding-bottom: 20px; }
		.contenedor-programa{width: 70%; margin: auto; display: table;}
		.portada{width: 95%; -webkit-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			-moz-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75); margin: auto; padding: 10px;}
			.contenido-programa{width: 100%; text-align: justify;}
			.portada .img-archivo{width: 100%; height: 500px;}
			.contenedor-volver{width: 100%;  text-align: center; display: table; padding-top: 5px; padding-bottom: 5px;}
			.contenedor-volver button{padding-top: 8px; padding-bottom: 8px; font-size: 15px; border: none;}
		}
		
		@media only screen and (min-width: 1200px) {	body{background-image: url("../plantilla_front/img/banner4.jpg"); background-size: cover;}
		.container-programa{width: 87.5%;  margin: auto;background-color: white; padding-top: 20px; padding-bottom: 20px; }
		.contenedor-programa{width: 70%; margin: auto; display: table;}
		.portada{width: 95%; -webkit-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			-moz-box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75);
			box-shadow: -1px 0px 11px 0px rgba(0,0,0,0.75); margin: auto; padding: 10px;}
			.contenido-programa{width: 100%; text-align: justify;}
			.portada .img-archivo{width: 100%; height: 500px;}
			.contenedor-volver{width: 100%;  text-align: center; display: table; padding-top: 5px; padding-bottom: 5px;}
			.contenedor-volver button{padding-top: 8px; padding-bottom: 8px; font-size: 15px; border: none;}
		}

		



		
	</style>
	
</head>
<body>
	<div class="container-programa">
		
		
		<br>

		
		

		
		
		<div class="contenedor-programa">
			<div class="title-section">
				<br>
				<h1  class="titulo_seccion" style="color:#0a8e5f;"><?php echo $blog['titulo_pub']; ?></h1>
				<br>
				<br>
			</div>
			<div class="portada" style="text-align: center;" id="<?php echo $blog['tipo_portada']; ?>">
				<?php echo "<img class='img-archivo' src='../".$blog['portada_pub']."'>" ?>
				<div class="contenido-programa">
					
					<p style="text-align: justify;"><?php echo $blog['contenido_pub']; ?></p>
					<br>
					
				</div>
			</div>
			
			

		</div>
		
		<div class="contenedor-volver"><br><button class="btn-volver" style="background-color: #a43474;"><a href="../inicio" style="color:white;">Volver</a></button></div>
		






	</div>
	 <div class="footer" id="contacto">
      <div class="title-section" id="title-footer">
        <h1 style="color:white;">Contactate con nosotros</h1>

      </div>  
      <div class="column-footer">
        <div class="cont">
          <form action="../contactos/crear_contacto" class="formulario-contacto-famevida" method="post">
            <div class="form-group">
              <label for="" class="info">Nombre completo</label>
              <input type="text" placeholder="Nombre completo" name="usuario_contacto_nombre" class="info" id="info-nombre-input" required autocomplete="off">
              <input type="hidden" name="tipo_peticion" value="31">
            </div>
            <div class="form-group">
              <label for="" class="info">Telefono</label>
              <input type="text" placeholder="Telefono" name="telefono" class="info" id="info-nombre-input" required autocomplete="off">

            </div>
            <div class="form-group">
              <label for="" class="info">Correo electronico</label>
              <input type="email" placeholder="Correo electronico" name="usuario_contacto_correo" class="info" id="info-nombre-input" required autocomplete="off">
            </div>
            <div class="form-group">
              <label for="" class="info">Mensaje</label>
              <input type="text" placeholder="Escriba aqui su mensaje" name="usuario_contacto_mensaje" class="info" id="info-mensaje-input" required autocomplete="off">
            </div>
            <div class="form-group">

              <input type="submit"value="Enviar" class="submit">
            </div>
          </form>
        </div>
      </div>
      <div class="column-footer">
        <div class="cont">
          <center>  <iframe class="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3982.572409296878!2d-76.49205778524184!3d3.453610197486307!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e30a7bab759cb03%3A0xf5529439348f292!2sCra.%207v%20%2361-11%2C%20Cali%2C%20Valle%20del%20Cauca!5e0!3m2!1ses-419!2sco!4v1603218401649!5m2!1ses-419!2sco" width="90%" height="320px;" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></center>
        </div>
      </div>
      <div class="contador-visitas" style="width: 100%; padding: 10px; float: left; text-align: center; color: white; font-size: 40px;">
        <?php
        $peticion_select_visitas = $instancia -> consultar_visitas();
        foreach($peticion_select_visitas as $visitas){

        }
        ?>






        <div class="visitas" style=" margin: auto; text-align: center;"><label for="">Visitantes</label></div>

        <div class="conteo" style="margin: auto;">
          <h4 class="total"><?php echo $visitas['count(*)'] ?></h4>
        </div>
        
      </div>


    </div>
	 <div class="redes-sociales-footer">
      <div class="redes-footer">
        <div class="red-footer"><div class="ico-footer"><i class="fa fa-facebook-square facebook-principal" id="facebook" title="https://www.facebook.com/1411389738880515/posts/3412431098776359/"> </i></div></div>
        <div class="red-footer"><div class="ico-footer"><i class="fa fa-instagram instagram-principal" id="facebook" title="https://www.instagram.com/p/CFwilP1jypt/?igshid=15sk4wmu105ww"></i></div></div>
        <div class="red-footer"><div class="ico-footer"><i class="fa fa-youtube youtube-pricipal" id="facebook" title="https://www.youtube.com/channel/UC3jdF1RqyjaW4VS6BKOo0mw"></i></div></div>
        <div class="red-footer"><div class="ico-footer"><i class="fa fa-twitter twitter-principal" id="facebook" title="https://twitter.com/famevida?s=09"></i></div></div>
      </div>
      <br>
      <hr>
      <br>
     
      <div class="datos-contacto">
        <div class="data-contact">
          <div class="column-data">
            <div class="con-title">
              <h2 class="title-data">Contactos</h2> 
            </div>
            <div class="data-data">
              <p>Carrera 7 v # 61 - 11 </p>
              <p>Cali - Valle del cauca -Colombia</p>
            </div>

          </div>
        </div>
        <div class="data-contact">
          <div class="column-data">
            <div class="con-title">
              <h2 class="title-data">Telefonos</h2> 
            </div>
            <div class="data-data">
              <p><a href="#">3459704</a></p>
              <p><a href="#">3164884196</a></p>

            </div>
          </div>
        </div>
        <div class="data-contact">
          <div class="column-data">
            <div class="con-title">
              <h2 class="title-data">Correo</h2>  
            </div>
            <div class="data-data">
              <p>Email : info@famevida.com</p>
              
            </div>
          </div>
        </div>


      </div>
      <div class="copyright">
        <div class="autor-page">
          © 2020 FAMEVIDA . All Rights Reserved | Design by Redepyme
        
        </div>  
      </div>
    </div>
    <script>
         $(".facebook-principal").click(function(){
          var enlace_red = $(this).attr("title");
   window.open(enlace_red);
        });
        
        
         $(".instagram-principal").click(function(){
          var enlace_red = $(this).attr("title");
   window.open(enlace_red);
        });
        
        
         $(".youtube-pricipal").click(function(){
          var enlace_red = $(this).attr("title");
   window.open(enlace_red);
        });
         $(".twitter-principal").click(function(){
          var enlace_red = $(this).attr("title");
   window.open(enlace_red);
        });
        
        $(".portada").each(function(){
           var tipo_portada = $(this).attr("id");
           if(tipo_portada == "ve"){
             var ruta = $(this).children().attr("src");
             var ruta_convertida = ruta.slice(3);
             alert(ruta_convertida);
             $(this).children(".img-archivo").replaceWith("<iframe src='"+ruta_convertida+"' style='border:none' class='img-archivo'>");
           }
           
            if(tipo_portada == "ie"){
             var ruta = $(this).children().attr("src");
             var ruta_convertida = ruta.slice(3);
             alert(ruta_convertida);
             $(this).children(".img-archivo").attr("src",ruta_convertida);
           }
        });
    </script>

</body>
</html>