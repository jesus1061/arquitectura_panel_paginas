<header>
  <div class="main">
    <div class="logotipo-contenedor">
      <img src="../plantilla_back/img/logo.png" alt="" class="logotipo-img">
      <br>
      <label for=""><?php echo $_SESSION['usuario']; ?></label> <label for="">/</label><label for="" style="color:blue;cursor:pointer" class="btn-cerrar-sesion"> Cerrar sesion</label> 
    </div>
    <div class="main-option">
      <div class="option">

        <div class="option-cont">
          <div class="item-option">
            <li  id="menu-multimedia">Modulo Multimedia</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion1">Cargar imagenes internas</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion2">Cargar imagenes externas</li>
          </div>

          <div class="item-option-sub">
            <li id="opcion3">Cargar videos externos</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion4">Ver archivos </li>
          </div>
        </div>

        <div class="option-cont">
          <div class="item-option">
            <li id="menu-blog">Modulo Slider</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion5">Crear Banner</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion6">ver Banners</li>
          </div>
        </div>

        <div class="option-cont">
          <div class="item-option">
            <li id="menu-blog">Modulo  galeria</li>
          </div>
          <div class="item-option-sub">
            <li ><label id="opcion7" style="color:blue; cursor: pointer;">Crear Albúm</label> /  <label id="opcion8" style="color:blue; cursor: pointer;">Crear elemento</label> </li>
          </div>
          <div class="item-option-sub">
           <li ><label id="opcion9" style="color:blue; cursor: pointer;">Ver Albúmnes</label> /  <label id="opcion10" style="color:blue; cursor: pointer;">Ver elementos</label> </li>
          </div>
        </div>
        <div class="option-cont">
          <div class="item-option">
            <li id="menu-blog">Modulo blog</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion11">Crear blog</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion12">Ver blogs</li>
          </div>
        </div>
        <div class="option-cont">
          <div class="item-option">
            <li id="menu-data">Modulo programas</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion13">Crear programa</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion14">Ver Programas</li>
          </div>
        </div>
        <div class="option-cont">
          <div class="item-option">
            <li id="menu-data">Modulo estadistico</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion15">Ver visitas</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion16">Ver contactos</li>
          </div>
        </div>
        <div class="option-cont">
          <div class="item-option">
            <li  id="menu-multimedia">Modulo Talento humano</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion17">Crear talento humano</li>
          </div>
          <div class="item-option-sub">
            <li id="opcion18">Ver talento </li>
          </div>
        </div>
      </div>
    </div>

  </div>
</header>