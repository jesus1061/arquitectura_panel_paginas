<?php
include_once "application/controllers/select_controller.php";
$instancia = new Select_controller();
$peticion_select = $instancia -> listar_archivos();

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <link rel="shortcut icon"  href="../plantilla_front/img/pestana.ico"/>
  <meta charset="UTF-8">
  <title>Famevida - Dashboard</title>
  <meta name="viewport" content="width=device-width, user-scalable=no">
  
  <link rel="stylesheet" href="../plantilla_back/css/personalizacion.css">
  
  <script type="text/javascript" src="../plantilla_back/js/jquery.js"></script>
  <script src="../plantilla_back/js/enrutador.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css"/>
</head>
<body>
  <div class="container">
    <div id="foco" style="display: none">

    </div>
    <!-- <input type="text" value="<?php echo $_SESSION['foco']; ?>" class="foco" style="display: none">-->
    

    <?php
    include "header.php";
    ?>


    <div class="contenedor-dinamico-admin">
      <div class="contenedor-ajustado">
       <div class="archivos-multimedia-container">


        <div class="archivos">
          <div class="encabezado-formulario">
            Listado de archivos cargados en el servidor
          </div>
          <?php

          foreach($peticion_select as $archivo){
            echo "<div class='archivo'>
            <div class='cont-archivo' id='".$archivo['id_archivo']."' title='".$archivo['tipo_archivo']."'>

            ".$archivo['archivo']."
            <br>
            <span class='nombre-archivo-label'>".$archivo['nombre_archivo']."</span>

            <br>

            <div class='opciones-archivo'>
            <i class='fa fa-trash' id='btn-borrar-archivo' title='".$archivo['id_archivo']."'></i>

            </div>

            </div>
            </div>
            ";

          }
          ?>






        </div>  
      </div>

    </div>

  </div>



</div>
<div class="confirmar_eliminar"></div>


<script>
  $(document).ready(function(){

 /*   $(".img-archivo").each(function(){
     var tipo_archivo = $(this).parent().attr("title");

     if(tipo_archivo == 'ii'){
      var ruta_sistema = $(this).attr("src");
      ruta_visualizacion = ruta_sistema.slice(3);
      $(this).attr("src",ruta_visualizacion);
    }

  });*/


    $(".fa-trash").click(function(){
      var id_archivo = $(this).attr("title");
      alertify.confirm('Eliminar archivo multimedia', '¿Deseas eliminar este archivo?', function(){ alertify.success('Archivo eliminado con exito');



        $.ajax({
                data:  { archivo_id:id_archivo}, //datos que se envian a traves de ajax
                url:   'eliminar_archivo', //archivo que recibe la peticion
                type:  'post', //método de envio
                beforeSend: function () {
                  //$(".respuesta").html("Procesando, espere por favor...");
                },
                success:  function (response) { //una vez que el archivo recibe el request lo procesa y lo devuelve
                 $(".confirmar_eliminar").html(response);


                  //$(".confirmar_eliminar").load("archivos_multimedia.php");
                  //alert("Borrar");
                }
              });








      }
      , function(){ alertify.error('Cancel')});

      
    });
    
  });
</script>


</body>
</html>