<?php
include_once "application/controllers/select_controller.php";
$instancia = new Select_controller();
extract($_POST);
$peticion_imagenes = $instancia -> listar_imagenes($album_id);
?>
<!DOCTYPE HTML>
<html lang="es">
<head>
	<link rel="shortcut icon"  href="../plantilla_front/img/pestana.ico"/>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<meta name="description" content="A touchable jQuery lightbox plugin for desktop, mobile and tablet" />
	<meta property="og:site_name" content="Swipebox" />
	<meta property="og:url" content="http://brutaldesign.github.com/swipebox/" />
	<meta property="og:image" content="http://swipebox.csag.co/images/swipe250.jpg" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Swipebox | A touchable jQuery lightbox" />
	<meta property="og:description" content="Swipebox is a jQuery lightbox plugin for desktop, mobile and tablet">
	<meta itemprop="name" content="Swipebox | A touchable jQuery lightbox">
	<meta itemprop="image" content="http://swipebox.csag.co/images/swipe250.jpg">
	<meta itemprop="description" content="Swipebox is a jQuery lightbox plugin for desktop, mobile and tablet">
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700|Merriweather:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" href="../plantilla_front/css/bagpakk.min.css">
	<link rel="stylesheet" href="../plantilla_front/css/style-gallery.css">
	<link rel="stylesheet" href="../plantilla_front/css/swipebox.css">
	<link rel="stylesheet" href="../plantilla_front/css/new.css">
	<title>Famevida - Galería</title>
	<!-- share buttons -->
	

	<style>
		body{background-image: url("../plantilla_front/img/banner3.jpg"); background-size: cover;}
		.cont{box-shadow: 0px 0px 0px 0px rgba(0,0,0,0.75);}
		.box{
			padding: 20px;
		}
		.volver-btn{
			background-color:#0a8e5f;
			color: white;
			font-size: 25px;
			font-style: oblique;
			border: none;
			padding-left: 10px;
			padding-right: 10px;
			cursor: pointer;
		}

		@media only screen and (max-width: 600px) {
			.box{
				width: 100%;
				float: left;

			}
			
		}

		@media only screen and (min-width: 600px) {
			.box{
				width: 100%;
				float: left;
			}
		}

		@media only screen and (min-width: 768px) {
			.box{
				width: 100%;
				float: left;
			}
		}
		@media only screen and (min-width: 992px) {
			.box{
				width: 100%;
				float: left;
			}
		}
		@media only screen and (min-width: 1200px) {
			.box{
				width: 100%;
				float: left;

			}
		}
	</style>

</head>
<body>
	
	
	

	<section  class="container" id="container-galeria-seleccionada" style="background-color: rgb(255,255,255,0.70); padding-top: 20px; padding-bottom: 20px;">
		<div class="title-section">
			<h4  class="titulo_seccion" style="color:#0a8e5f;">AlBÚM FOTOGRÁFICO</h4>
		</div>
		<div class="cont">

			<ul id="box-container">

				<?php
				foreach($peticion_imagenes as $imagen){
					echo '
					<li class="box" style="text-align: center">
					<a href="'.$imagen['contenido_galeria_foto'].'" class="swipebox" title="'.$imagen['contenido_galeria_nombre'].'">
					<img class="img-archivo" src="../'.$imagen['contenido_galeria_foto'].'" alt="image" style="width:95%;" id="'.$imagen['tipo_portada'].'" >
					</a>
					</li>
					';
				}
				?>


			</ul>

			<div class="volver" style="width: 100%; text-align: center;">
				<button class="volver-btn">Volver</button>
			</div>
		</div>
	</section>









	<script src="../plantilla_front/js/ios-orientationchange-fix.js"></script>
	<script src="../plantilla_front/js/jquery-2.1.0.min.js"></script>
	<script src="../plantilla_front/js/jquery.swipebox.js"></script>
	<script type="text/javascript">
		$( document ).ready(function() {
		     $(".img-archivo").each(function(){
			       var ruta = $(this).attr("src");
			       var tipo_archivo = $(this).attr("id");
			      // alert(tipo_archivo);
			      if(tipo_archivo == "ie"){
			           var ruta_convertida = ruta.slice(3);
			       $(this).attr("src",ruta_convertida);
			      $(this).parent().attr("href",ruta_convertida);
			      
			      }else{
			          var ruta_convertida = ruta.slice(0);
			       $(this).attr("src",ruta_convertida);
			      $(this).parent().attr("href",ruta_convertida); 
			          
			      }
			        
			    });

			/* Basic Gallery */
			$( '.swipebox' ).swipebox();

			/* Video */
			$( '.swipebox-video' ).swipebox();

			/* Dynamic Gallery */
			$( '#gallery' ).click( function( e ) {
				e.preventDefault();
				$.swipebox( [
					{ href : 'http://swipebox.csag.co/mages/image-1.jpg', title : 'My Caption' },
					{ href : 'http://swipebox.csag.co/images/image-2.jpg', title : 'My Second Caption' }
					] );
			} );


			$(".volver-btn").click(function(){
				window.location.href = '../blog/lanzar_galeria';
			});

		});
	</script>

</body>

</html>