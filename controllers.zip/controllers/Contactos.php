<?php
session_start();
error_reporting(0);
include_once "application/models/contacto_model.php";
defined('BASEPATH') OR exit('No direct script access allowed');

class Contactos extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function inicio()
	{
		
		if (isset($_SESSION['usuario'])) 
		{
			$this->load->view('ver_contactos.php');
			
			

		}else{

			echo '<script>alert("Su sesión termino");</script>';
			echo '<script>
			window.location.href = "../panel/inicio";
			</script>';
		}
	}

	public function listar_contactos(){
		$instancia = new Contacto_model();
		$peticion_select = $instancia ->ver_contactos();
		return $peticion_select;
	}
	
	
	public function crear_contacto(){
	   
	    extract($_POST);
	    	$instancia = new Contacto_model();
		$peticion_insert = $instancia ->crear_contacto($usuario_contacto_nombre, $telefono , $usuario_contacto_correo , $usuario_contacto_mensaje);
		



require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';
require 'OAuth.php';

$mail = new PHPMailer\PHPMailer\PHPMailer();
$destino = $usuario_contacto_correo;

$mail->isSMTP();
$mail->SMTPDebug = 0; //para ver los errores del lado del cliente y servidor
$mail->Debugoutput = 'html';
$mail->Host = 'famevida.org'; //servidor saliente stmp
$mail->Port = 465; //puerto 465 para ssl
$mail->SMTPSecure = "ssl";
$mail->SMTPAuth = true; //requiere auth
$mail->Username = "info@famevida.org";
$mail->Password = "infofamevida2020";
$mail->setFrom('info@famevida.org', 'Famevida'); //desde:
$mail->addReplyTo('info@famevida.org', 'Famevida'); //responder a :
$mail->addAddress($destino, ''); //para :
$mail->Subject = 'Bienvenido a Famevida';// asunto
$mail->Body = "<img src='www.famevida.org/plantilla_front/img/logo.png' style='width:100%; height:70px'><br><h1 style='color:#a43474'>".$usuario_contacto_nombre." Bienvenido(a) a Famevida</h1><br>
<p STYLE='font-size:20px; font-weigth:900'>Para Famevida es muy importante contar con su valiosa sugerencia gracias por comunicarte con nosotros pronto nos comunicaremos con usted</p>"; //cuerpo
$mail->AltBody = 'Esto es texto plano'; //cuerpo alternativo en texto plano
$mail->SMTPOptions = array(  //necesario sino me larga error
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
if (!$mail->send()) {  //envio el email
    echo "Mailer Error: " . $mail->ErrorInfo; //catch de error
} else {
    echo "<script>
    alert('Tu mensaje ha sido enviado satisfactoriamente pronto nos comunicaremos con usted');
    window.location.href = 'https://www.famevida.org';
    </script>"; // respuesta si se envia
}






		

	
		
		
	

		
	}



	
}

